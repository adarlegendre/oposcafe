from django.apps import AppConfig


class OposappConfig(AppConfig):
    name = 'oposapp'
