from django.apps import AppConfig


class OposcafeConfig(AppConfig):
    name = 'oposcafe'
