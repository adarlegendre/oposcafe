from django.apps import AppConfig


class SunnyirrigationConfig(AppConfig):
    name = 'sunnyirrigation'
