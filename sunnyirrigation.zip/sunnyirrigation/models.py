from django.db import models

class System_info(models.Model):
    name = models.CharField(max_length=50)
    desc = models.CharField(max_length=200)
    photo = models.FileField(upload_to='documents/sunnyirrigation/logo')
    location = models.CharField(max_length=200)
    def __str__ (self):
        return self.name
    class Meta:
        verbose_name_plural = "System Information"

class Customers(models.Model):
    name = models.CharField(max_length=50)
    desc = models.CharField(max_length=200)
    photo = models.FileField(upload_to='documents/sunnyirrigation/logo')
    location = models.CharField(max_length=200)
    def __str__ (self):
        return self.name
    class Meta:
        verbose_name_plural = "System Information"

class Stations(models.Model):
    name = models.CharField(max_length=50)
    desc = models.CharField(max_length=200)
    photo = models.FileField(upload_to='documents/sunnyirrigation/logo')
    location = models.CharField(max_length=200)
    def __str__ (self):
        return self.name
    class Meta:
        verbose_name_plural = "System Information"

class Planning(models.Model):
    name = models.CharField(max_length=50)
    desc = models.CharField(max_length=200)
    photo = models.FileField(upload_to='documents/sunnyirrigation/logo')
    location = models.CharField(max_length=200)
    def __str__ (self):
        return self.name
    class Meta:
        verbose_name_plural = "System Information"